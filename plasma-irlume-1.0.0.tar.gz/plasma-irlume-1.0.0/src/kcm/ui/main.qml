// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick
import QtQuick.Controls as QQC2
import QtQuick.Layouts
import org.kde.kcmutils as KCMUtils

KCMUtils.SimpleKCM {
    id: root

    title: i18n("Face Login")
    KCMUtils.ConfigModule.buttons: KCMUtils.ConfigModule.NoAdditionalButton

    header: QQC2.TabBar {
        id: tabs

        width: parent.width
        Accessible.name: i18n("Face Login sections")
        KeyNavigation.down: currentIndex === 0 ? overview : (currentIndex === 1 ? enrollment : (currentIndex === 2 ? authentication : (currentIndex === 3 ? security : diagnostics)))

        QQC2.TabButton {
            text: i18n("Overview")
            icon.name: "view-dashboard"
            display: tabs.width < 520 ? QQC2.AbstractButton.IconOnly : QQC2.AbstractButton.TextOnly
            Accessible.name: text
        }

        QQC2.TabButton {
            text: i18n("Face profile")
            icon.name: "user-identity"
            display: tabs.width < 520 ? QQC2.AbstractButton.IconOnly : QQC2.AbstractButton.TextOnly
            Accessible.name: text
        }

        QQC2.TabButton {
            text: i18n("Authentication")
            icon.name: "preferences-system-login"
            display: tabs.width < 520 ? QQC2.AbstractButton.IconOnly : QQC2.AbstractButton.TextOnly
            Accessible.name: text
        }

        QQC2.TabButton {
            text: i18n("Security")
            icon.name: "security-high"
            display: tabs.width < 520 ? QQC2.AbstractButton.IconOnly : QQC2.AbstractButton.TextOnly
            Accessible.name: text
        }

        QQC2.TabButton {
            text: i18n("Diagnostics")
            icon.name: "tools-report-bug"
            display: tabs.width < 520 ? QQC2.AbstractButton.IconOnly : QQC2.AbstractButton.TextOnly
            Accessible.name: text
        }
    }

    ColumnLayout {
        width: parent.width
        spacing: 0

        OverviewPage {
            id: overview

            Layout.fillWidth: true
            visible: tabs.currentIndex === 0
            enabled: visible
            systemState: kcm.systemState
        }

        SecurityPage {
            id: security

            Layout.fillWidth: true
            visible: tabs.currentIndex === 3
            enabled: visible
            systemState: kcm.systemState
        }

        EnrollmentPage {
            id: enrollment

            Layout.fillWidth: true
            visible: tabs.currentIndex === 1
            enabled: visible
            systemState: kcm.systemState
            profileModel: kcm.profileModel
        }

        AuthenticationPage {
            id: authentication

            Layout.fillWidth: true
            visible: tabs.currentIndex === 2
            enabled: visible
            systemState: kcm.systemState
            authConfiguration: kcm.authConfiguration
        }

        DiagnosticsPage {
            id: diagnostics

            Layout.fillWidth: true
            visible: tabs.currentIndex === 4
            enabled: visible
            systemState: kcm.systemState
            authConfiguration: kcm.authConfiguration
            supportReport: kcm.supportReport
            refresh: () => kcm.refresh()
        }
    }
}
