# V2 Implementation Status

## Product goal

V2 turns Face Login into a guided KDE workflow with four task-oriented areas:
**Setup & Status**, **Face Profiles**, **Access**, and **Support**. Live state
always comes from the engine and system probes; the KCM does not persist an
optimistic completion flag.

The visual direction is Plasma-native biometric readiness: a compact
next-action dashboard, a six-step readiness path, and an in-memory camera
preview with landmarks and redundant text guidance. System colors, typography,
focus handling, and controls remain authoritative.

## Implemented locally

- contract-v2 capability negotiation for `profiles-json`, `events-jsonl`,
  `position-report`, and `preview-ir-jpeg`;
- a dedicated `EnrollmentSession` process boundary for enrollment,
  improve-recognition, and non-authenticating recognition tests;
- bounded JPEG validation (640 by 480, 128 KiB), 8 fps backpressure, monotonic
  event sequences, session IDs, typed positioning, cancellation, timeout, and
  memory clearing;
- a deliberately separate painted preview item; the normal diagnostic adapter
  still rejects image and biometric fields;
- IR/RGB labeling, face box, exactly 478 normalized landmarks, countdown,
  quality, and text checklist;
- preview cancellation and buffer clearing when the profile page is hidden;
- engine-advertised profile-count limits;
- profile and scan rename, guarded single-scan deletion, and exact
  before/after mutation validation;
- explicit confirmation when enrollment merges into an existing identity, with
  exact scan-ID cleanup on decline or failed recognition verification;
- four task-oriented areas and a live-state setup path;
- existing fixed KAuth plan, apply, verify, rollback, and emergency-disable
  boundary retained for Access;
- a `CameraConfiguration` model that gates on `camera-config-json`, validates
  bounded secure-pair labels and opaque IDs, and exposes only typed camera,
  emitter, and capture-mode state;
- fixed KAuth actions for camera selection, emitter setup, and capture tuning;
  selection is read back independently, emitter setup is followed by a
  non-mutating probe, and no device path or free-form engine argument is
  accepted;
- QML creation tests at 320, 480, and 960 logical pixels and a warning-free
  repository lint command.

## Deliberately gated

No released irlume engine currently publishes the reviewed V2 contract.
Consequently, irlume 0.6.x remains read-only and production enrollment,
preview, profile mutation, and login mutation stay unavailable. Synthetic
fixtures and unit tests prove the consumer boundary, not upstream support.

The following items cannot be marked release-complete in this repository:

- upstream schemas, implementation, tests, and release-derived fixtures;
- release-derived validation of profile rename, individual scan deletion, and
  identity-merge results;
- daemon-restart reconnection against a real V2 engine;
- real Secure IR and RGB Convenience hardware;
- Fedora 44 clean install, V1-to-V2 upgrade, password fallback, and terminal
  successful public COPR installation.

Stable `2.0.0` publication is blocked until every item above has release
evidence. The private daemon protocol, human CLI parsing for mutation, and
parallel camera access are never acceptable substitutes.

## Qualification evidence

The following evidence was refreshed on 2026-07-26:

- the complete local build, CTest, Python fixture, QML lint, C++ formatting,
  source archive, RPM build, rpmlint, and isolated package lifecycle gates
  passed;
- a host upgrade from `1.0.0-1.fc44` to `2.0.0-0.1.dev.fc44` preserved the
  engine status and every PAM file digest;
- official irlume `0.6.1` and upstream `main` at
  `82165049f95440b281b78f3152dcd8901e4effbf` do not publish the required
  machine contract; upstream tracking is
  [archledger/irlume#108](https://github.com/archledger/irlume/issues/108).
  The consolidated implementation is under upstream review in
  [archledger/irlume#115](https://github.com/archledger/irlume/pull/115). It
  provides the complete versioned JSON/JSONL profile, preview, cancellation,
  exact merge-lineage, login-transaction, and bounded camera configuration
  contract required by this consumer. It remains prerelease evidence until it
  is merged, documented, and published in an official irlume release;
- PR #115 commit `e5938798c544ae0bc83f716f95b136c09c2302e2`
  passed Packit builds for Fedora 43 and Fedora 44. The Fedora 44 PR RPM was
  installed on Secure IR hardware and independently confirmed:
  `camera-config-json` capability discovery, one bounded active secure pair,
  ordinary-user camera listing and emitter probing, authorized selection with
  exact readback, bounded capture tuning, daemon restart reconnection, and an
  unchanged PAM digest set. The emitter setup operation returned the expected
  typed `hardware-unavailable` result on hardware whose IR emitter has no
  software-controllable extension unit; the separate non-mutating probe still
  reported four available controls;
- the same live RPM qualification exposed and fixed a packaging regression in
  PR #115: an empty package-created group had made the daemon socket
  unreachable to desktop and greeter clients. The corrected package recreates
  `/run/irlume.sock` as `0666 root:root`, requires no per-user ACL or group
  membership, and retains per-request root-or-self authorization through
  `SO_PEERCRED`. Ordinary-user version and camera probes passed after a clean
  daemon restart;
- PR #115 final head `d28527a18a2ad991d210c526e82ad92d608de905`
  passed the complete non-hardware-gated Rust workspace suite, workspace
  clippy with warnings as errors, formatting, rustdoc, and Packit Fedora 43/44
  builds. Its Fedora 44 RPM passed `rpm -V`, retained the verified socket and
  camera behavior after restart, and made `irlume enroll --help` a proven
  non-capturing operation: exit 0, no daemon journal entry, and identical
  empty profile state before and after;
- the locally built `plasma-irlume-2.0.0-0.1.dev.fc44` RPM was reinstalled on
  Fedora 44, passed `rpm -V`, exposed every fixed camera KAuth policy action,
  opened through `kcmshell6` without QML/runtime errors, and passed the
  isolated install/uninstall lifecycle smoke test;
- COPR build
  [`10774932`](https://copr.fedorainfracloud.org/coprs/build/10774932) reports
  terminal `succeeded` for the V1 package after the earlier Pulp outage.
  Regenerated repository metadata publishes `1.0.0-1.fc44`, and a clean
  Fedora 44 container installed and verified `plasma-irlume`, `irlume`, and
  `irlume-selinux` from the two public COPR repositories. The recovery evidence
  is recorded in
  [fedora-copr/copr#4401](https://github.com/fedora-copr/copr/issues/4401#issuecomment-5084418359).

The COPR publication blocker is resolved for V1. Synthetic contract fixtures
still do not satisfy the stable V2 release gate.

## Upstream handoff

The exact required transport is specified in
[`UPSTREAM-API-REQUEST.md`](UPSTREAM-API-REQUEST.md). Once an official release
exists:

1. pin the accepted engine range and replace synthetic payloads with sanitized
   release-derived fixtures;
2. execute failure injection for cancellation, oversized and stale frames,
   daemon restart, verification failure, and rollback;
3. confirm the release-derived profile and camera results against the already
   gated consumer operations;
4. run the complete hardware and Fedora package matrix in
   [`TEST-MATRIX.md`](TEST-MATRIX.md);
5. only then change the Fedora dependency to the reviewed minimum engine and
   publish stable `2.0.0`.
